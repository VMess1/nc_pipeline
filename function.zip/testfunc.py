import boto3
import random
import string

s3 = boto3.client('s3')

def handler(event, context):
    try:
        # Generate a random key for the S3 object
        random_key = ''.join(random.choice(string.ascii_letters) for _ in range(10))

        # Put a random object into the S3 bucket
        response = s3.put_object(
            Bucket="nc-group3-ingestion-bucket",
            Key=random_key,
            Body="hi"
        )

        return {
            'statusCode': 200,
            'body': f'Object with key {random_key} created in the S3 bucket'
        }
    except Exception as e:
        print(f"Error from put_object: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'
        }

# TestFunction for testing terraform 

# import boto3
# from botocore.exceptions import ClientError

# s3 = boto3.client('s3')

# def handler(event, context):
#     try:
#         response = s3.put_object(
#             Bucket= "nc-group3-ingestion-bucket",
#             Key= "blah",
#             Body= "hi")
#         return {
#             'headers': { ... },
#             'statusCode': 200
#         }
#     except ClientError as e:
#         print("Error from put_object", event)
#         return {
#             'headers': { ... },
#             'statusCode': 500
#         }
