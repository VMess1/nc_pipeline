
version = "1.26.1"
__version__ = version
full_version = version

git_revision = "411a55b9ec084c3315fe5f199351c31d0eb3c352"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
